import os
import streamlit as st
import pandas as pd
import numpy as np
from sentiment_model import load_model_or_pipeline
from summarization import summarize_short_and_detailed
from insights import extract_top_terms, prepare_sentiment_ratio, forecast_next_month
import matplotlib.pyplot as plt

st.set_page_config(page_title='Customer Feedback AI', layout='wide')

st.title('Customer Feedback AI: Sentiment, Summarization, Insights')

uploaded = st.file_uploader('Upload feedback CSV (columns: feedback_text, date optional)', type=['csv'])

@st.cache_data
def load_data(file):
    df = pd.read_csv(file)
    if 'feedback_text' not in df.columns:
        st.error('CSV must include feedback_text column')
        st.stop()
    if 'label' not in df.columns:
        df['label'] = 'Neutral'
    return df

clf, id2label = load_model_or_pipeline()

if uploaded:
    df = load_data(uploaded)

    st.subheader('Sample of Uploaded Data')
    st.dataframe(df.head())

    # Sentiment Prediction
    st.subheader('Sentiment Analysis')
    sample_texts = df['feedback_text'].astype(str).fillna('').tolist()
    to_predict = sample_texts[:200]  # cap for demo speed
    preds = clf(to_predict)
    pred_labels = [p['label'] if isinstance(p, dict) else p for p in preds]
    df.loc[:len(pred_labels)-1, 'predicted_sentiment'] = pred_labels

    st.write('Predicted sentiment distribution:')
    st.bar_chart(df['predicted_sentiment'].value_counts())

    # Summarization of long concatenated feedback
    st.subheader('Summaries')
    long_text = ' '.join(sample_texts[:200])
    short, detailed = summarize_short_and_detailed(long_text)
    st.markdown('**Short Summary**')
    st.write(short)
    st.markdown('**Detailed Summary**')
    st.write(detailed)

    # Insights
    st.subheader('Insights')
    text_col = 'feedback_text'
    top_terms = extract_top_terms(df[text_col].astype(str).tolist(), top_k=15)
    terms, scores = zip(*top_terms)
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.barh(list(terms)[::-1], list(scores)[::-1])
    ax.set_title('Top Recurring Terms')
    st.pyplot(fig)

    # Forecast
    if 'date' not in df.columns:
        st.info('No date column provided; synthesizing dates for demo')
        df['date'] = pd.date_range('2023-01-01', periods=len(df), freq='D')
    monthly = prepare_sentiment_ratio(df.rename(columns={'predicted_sentiment': 'label'}))
    fc, monthly_series = forecast_next_month(monthly)
    st.write(f"Forecasted next-month positive satisfaction rate: {fc:.2%}")
    st.line_chart(monthly_series['positive_rate'])

    # Download enriched CSV
    st.subheader('Download Results')
    st.download_button('Download predictions CSV', data=df.to_csv(index=False), file_name='predicted_feedback.csv')
else:
    st.info('Upload a CSV to begin.')
