import os
import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import KMeans
from collections import Counter
import matplotlib.pyplot as plt
from statsmodels.tsa.arima.model import ARIMA
from matplotlib.backends.backend_pdf import PdfPages

os.makedirs('reports', exist_ok=True)


def extract_top_terms(texts, top_k=15):
    vectorizer = TfidfVectorizer(max_features=5000, ngram_range=(1, 2), min_df=2)
    X = vectorizer.fit_transform(texts)
    scores = np.asarray(X.sum(axis=0)).ravel()
    terms = np.array(vectorizer.get_feature_names_out())
    idx = np.argsort(scores)[::-1][:top_k]
    return list(zip(terms[idx], scores[idx]))


def prepare_sentiment_ratio(df):
    if 'date' in df.columns:
        df['date'] = pd.to_datetime(df['date'])
    else:
        df['date'] = pd.date_range('2023-01-01', periods=len(df), freq='D')
    df['is_positive'] = (df['label'].astype(str).str.lower() == 'positive').astype(int)
    monthly = df.groupby(pd.Grouper(key='date', freq='M'))['is_positive'].mean().rename('positive_rate').to_frame()
    monthly.index = monthly.index.to_period('M').to_timestamp()
    return monthly


def forecast_next_month(monthly):
    if len(monthly) < 3:
        # not enough data; naive forecast
        last = monthly['positive_rate'].iloc[-1]
        return last, monthly
    model = ARIMA(monthly['positive_rate'], order=(1, 1, 1))
    res = model.fit()
    fc = res.forecast(steps=1)[0]
    return float(fc), monthly


def make_report(clean_csv='data/cleaned_feedback.csv', out_pdf='reports/AI_insights_report.pdf'):
    df = pd.read_csv(clean_csv)
    text_col = 'preprocessed_text' if 'preprocessed_text' in df.columns else 'feedback_text'

    top_terms = extract_top_terms(df[text_col].astype(str).tolist(), top_k=20)

    monthly = prepare_sentiment_ratio(df)
    fc, monthly_series = forecast_next_month(monthly)

    with PdfPages(out_pdf) as pdf:
        plt.figure(figsize=(8, 5))
        terms, scores = zip(*top_terms)
        plt.barh(terms[::-1], scores[::-1])
        plt.title('Top Recurring Terms (TF-IDF)')
        plt.tight_layout()
        pdf.savefig(); plt.close()

        plt.figure(figsize=(8, 5))
        plt.plot(monthly_series.index, monthly_series['positive_rate'], marker='o', label='Positive Rate')
        plt.title('Monthly Positive Satisfaction Rate')
        plt.ylim(0, 1)
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        pdf.savefig(); plt.close()

        plt.figure(figsize=(8, 4))
        plt.axis('off')
        txt = f"Forecasted next-month positive satisfaction rate: {fc:.2%}\n\n" \
              f"Top recurring issues/terms:\n" + "\n".join([f"- {t} (score {s:.2f})" for t, s in top_terms])
        plt.text(0.01, 0.99, txt, va='top', ha='left', fontsize=10)
        pdf.savefig(); plt.close()

    print('Report saved to', out_pdf)


if __name__ == '__main__':
    make_report()
