import os
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_recall_fscore_support
from transformers import AutoTokenizer, AutoModelForSequenceClassification, Trainer, TrainingArguments
import torch
import joblib

MODEL_DIR = 'models/sentiment_model'
META_PKL = 'models/sentiment_model.pkl'

os.makedirs('models', exist_ok=True)

LABEL2ID = {"Negative": 0, "Neutral": 1, "Positive": 2}
ID2LABEL = {v: k for k, v in LABEL2ID.items()}

class FeedbackDataset(torch.utils.data.Dataset):
    def __init__(self, texts, labels, tokenizer, max_len=128):
        self.encodings = tokenizer(texts, truncation=True, padding=True, max_length=max_len)
        self.labels = labels
    def __len__(self):
        return len(self.labels)
    def __getitem__(self, idx):
        item = {key: torch.tensor(val[idx]) for key, val in self.encodings.items()}
        item['labels'] = torch.tensor(self.labels[idx])
        return item


def train_and_save(clean_csv='data/cleaned_feedback.csv', epochs=1):
    df = pd.read_csv(clean_csv)
    text_col = 'preprocessed_text' if 'preprocessed_text' in df.columns else 'feedback_text'
    df = df.dropna(subset=[text_col, 'label'])
    df = df[df['label'].isin(LABEL2ID.keys())]
    df['y'] = df['label'].map(LABEL2ID)

    X_train, X_val, y_train, y_val = train_test_split(df[text_col].tolist(), df['y'].tolist(), test_size=0.2, random_state=42, stratify=df['y'])

    model_name = 'distilbert-base-uncased'
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model = AutoModelForSequenceClassification.from_pretrained(model_name, num_labels=3, id2label=ID2LABEL, label2id=LABEL2ID)

    train_ds = FeedbackDataset(X_train, y_train, tokenizer)
    val_ds = FeedbackDataset(X_val, y_val, tokenizer)

    args = TrainingArguments(
        output_dir='models/tmp_training',
        evaluation_strategy='epoch',
        per_device_train_batch_size=16,
        per_device_eval_batch_size=32,
        num_train_epochs=epochs,
        logging_steps=50,
        save_strategy='epoch',
        load_best_model_at_end=True,
        metric_for_best_model='accuracy'
    )

    def compute_metrics(eval_pred):
        logits, labels = eval_pred
        preds = np.argmax(logits, axis=-1)
        acc = accuracy_score(labels, preds)
        precision, recall, f1, _ = precision_recall_fscore_support(labels, preds, average='weighted', zero_division=0)
        return {'accuracy': acc, 'precision': precision, 'recall': recall, 'f1': f1}

    trainer = Trainer(model=model, args=args, train_dataset=train_ds, eval_dataset=val_ds, tokenizer=tokenizer, compute_metrics=compute_metrics)
    trainer.train()

    os.makedirs(MODEL_DIR, exist_ok=True)
    model.save_pretrained(MODEL_DIR)
    tokenizer.save_pretrained(MODEL_DIR)

    metrics = trainer.evaluate()
    meta = {'model_dir': MODEL_DIR, 'metrics': metrics, 'label2id': LABEL2ID, 'id2label': ID2LABEL}
    joblib.dump(meta, META_PKL)
    print('Model saved to', MODEL_DIR, 'and meta to', META_PKL)


def load_model_or_pipeline():
    from transformers import pipeline
    if os.path.isdir(MODEL_DIR) and os.path.exists(META_PKL):
        tokenizer = AutoTokenizer.from_pretrained(MODEL_DIR)
        model = AutoModelForSequenceClassification.from_pretrained(MODEL_DIR)
        clf = pipeline('sentiment-analysis', model=model, tokenizer=tokenizer, return_all_scores=False)
        return clf, ID2LABEL
    # fallback to pretrained generic pipeline (fast demo)
    clf = pipeline('sentiment-analysis')
    return clf, {0: 'NEGATIVE', 1: 'POSITIVE'}


def predict(texts):
    clf, _ = load_model_or_pipeline()
    if isinstance(texts, str):
        texts = [texts]
    results = clf(texts)
    return results


if __name__ == '__main__':
    os.makedirs('data', exist_ok=True)
    if not os.path.exists('data/cleaned_feedback.csv'):
        raise SystemExit('Cleaned data not found. Run data_preprocessing.py first.')
    train_and_save('data/cleaned_feedback.csv', epochs=1)
