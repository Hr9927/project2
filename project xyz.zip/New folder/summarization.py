from transformers import AutoTokenizer, AutoModelForSeq2SeqLM
import torch

MODEL_NAME = 't5-small'

tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForSeq2SeqLM.from_pretrained(MODEL_NAME)

def summarize_text(text: str, max_len: int = 60, min_len: int = 10) -> str:
    if not text:
        return ''
    input_text = 'summarize: ' + text.strip()
    inputs = tokenizer.encode(input_text, return_tensors='pt', truncation=True, max_length=512)
    summary_ids = model.generate(
        inputs,
        max_length=max_len,
        min_length=min_len,
        length_penalty=2.0,
        num_beams=4,
        early_stopping=True
    )
    return tokenizer.decode(summary_ids[0], skip_special_tokens=True)


def summarize_short_and_detailed(text: str):
    short = summarize_text(text, max_len=40, min_len=8)
    detailed = summarize_text(text, max_len=120, min_len=30)
    return short, detailed
