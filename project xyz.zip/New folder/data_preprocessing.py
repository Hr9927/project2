import pandas as pd
import numpy as np
import re
import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from tqdm import tqdm
import random
import os

nltk.download('punkt')
nltk.download('wordnet')
nltk.download('stopwords')

# Create data folder if it doesn't exist
os.makedirs('data', exist_ok=True)

def simulate_feedback_data(n=1200):
    sources = ['email', 'chat', 'social_media']
    sentiments = ['Positive', 'Negative', 'Neutral']
    base_texts = [
        "I love this product!", "I hate this service.", "It was ok, nothing special.",
        "Great customer support!", "Very disappointed with the quality.", "Could be better.", 
        "Absolutely fantastic!", "I want a refund.", "Super helpful staff!", "Too slow."
    ]
    feedbacks = []
    for i in range(n):
        source = random.choice(sources)
        sentiment = random.choice(sentiments)
        text = f"{random.choice(base_texts)}"
        feedbacks.append({
            'id': i + 1,
            'source': source,
            'feedback_text': text,
            'date': pd.Timestamp('2023-01-01') + pd.to_timedelta(random.randint(0, 364), unit='D'),
            'label': sentiment
        })
    return pd.DataFrame(feedbacks)

df = simulate_feedback_data(1200)
df.to_csv('data/raw_feedback.csv', index=False)

# Remove duplicates
df = df.drop_duplicates(subset=['feedback_text'])

def clean_text(text):
    text = str(text)
    text = re.sub(r'[^a-zA-Z\s]', '', text)
    text = text.lower()
    return text

df['cleaned_text'] = df['feedback_text'].apply(clean_text)

df = df.dropna(subset=['cleaned_text'])

lemmatizer = WordNetLemmatizer()
stop_words = set(stopwords.words('english'))

def preprocess_text(text):
    tokens = nltk.word_tokenize(text)
    tokens = [w for w in tokens if w not in stop_words]
    tokens = [lemmatizer.lemmatize(w) for w in tokens]
    return " ".join(tokens)

tqdm.pandas()
df['preprocessed_text'] = df['cleaned_text'].progress_apply(preprocess_text)

df[['id', 'source', 'feedback_text', 'date', 'label', 'preprocessed_text']].to_csv('data/cleaned_feedback.csv', index=False)
print('Cleaned data saved to data/cleaned_feedback.csv')

