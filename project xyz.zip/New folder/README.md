# Customer Feedback AI (Sentiment + Summarization + Insights)

## Quickstart

1. Create a virtual environment (recommended) and install deps:
```
pip install -r requirements.txt
```

2. Generate data (simulated) and cleaned dataset:
```
python data_preprocessing.py
```

3. (Optional) Train the sentiment model (quick 1 epoch):
```
python sentiment_model.py
```
This saves model in `models/sentiment_model/` and meta at `models/sentiment_model.pkl`.
If you skip this, the app uses a pretrained pipeline for demo.

4. Run the Streamlit app:
```
streamlit run app.py
```

Upload a CSV with at least `feedback_text` column (optional: `date`, `label`).
The app will show predicted sentiments, summaries, top terms, and a forecast.

## Deliverables
- Cleaned dataset: `data/cleaned_feedback.csv`
- Model: `models/sentiment_model/` plus `models/sentiment_model.pkl`
- Summarization: `summarization.py` (T5-small)
- Insights report: generated via `insights.py` → `reports/AI_insights_report.pdf`
- App: `app.py` (Streamlit)

## Notes
- For faster demo, app caps predictions to 200 rows.
- CPU-only inference is supported; training time depends on machine.
